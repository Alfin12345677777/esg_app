# junction2025
ESG analysis app for construction companies in South Korea
https://junction2025-afdd1.web.app/
